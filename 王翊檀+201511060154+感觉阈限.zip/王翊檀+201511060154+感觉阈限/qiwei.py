from PIL import Image
import os
work_dir ="C:/Users/喵喵/Desktop/感觉阈限/"
os.chdir(work_dir)
im = Image.open(work_dir+'戚薇大大.jpg').convert('L')
# im.save('graypic1.jpg')
from PIL import ImageDraw
draw = ImageDraw.Draw(im)
for x in range(1, 11):
    for i in range(0, list(im.size)[0]):
            for j in range(0, list(im.size)[1]):
                    color = im.getpixel((i, j))
                    # 改变灰度值
                    color = color + x
                    point = [i, j]
                    draw.point(point, color)
    # im.show('pic1.jpg')
    im.save('灰色的戚薇大大'+str(x-1)+'.jpg')
    PicNames=('灰色的戚薇大大'+str(x-1)+'.jpg')
    # 打印出我们所需要的格式

    for i in range(0, len(PicNames)):
        PicNames = ('灰色的戚薇大大' + str(x - 1) + '.jpg')
        i = i + 1
    print('/' + str(x) + '=' + '"' + PicNames + '"')
