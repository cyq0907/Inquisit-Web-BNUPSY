#批量生成不同灰度的刺激图片

from PIL import Image
from matplotlib import pylab
from pylab import *
import os

work_dir="/Users/Vince/Desktop/李文楷_差别阈限/Image"

im = array(Image.open('original.jpg').convert('L'))
im = 0.5*im + 50

for i in range(1,17):
    im = im + 3
    image = Image.fromarray(uint8(im)).resize((600,400))
    image.save(work_dir + "pic" + str(i-1) + ".jpg")

